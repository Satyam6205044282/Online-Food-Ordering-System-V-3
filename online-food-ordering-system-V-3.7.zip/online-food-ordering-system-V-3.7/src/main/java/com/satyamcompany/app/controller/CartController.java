package com.satyamcompany.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.satyamcompany.app.exception.CartNotFoundException;
import com.satyamcompany.app.model.Cart;
import com.satyamcompany.app.model.Menu;
import com.satyamcompany.app.service.MenuService;
import com.satyamcompany.app.service.CartService;


@RestController
@RequestMapping("/api")
public class CartController {
	
	@Autowired
	private CartService cartService;
	
	@Autowired
	private MenuService menuService;
	
	
	/**
	 * 
	 * @return
	 */
	@GetMapping("/carts")
	public ResponseEntity<List<Cart>> findAll(){ 
		//log
		return new ResponseEntity<>(cartService.findAll(),HttpStatus.OK);
	}
	
	@GetMapping("/carts/{id}") 
	public ResponseEntity<Cart> findById(@PathVariable("id") int customer_id) throws CartNotFoundException{
		return new ResponseEntity<Cart>(cartService.findById(customer_id), HttpStatus.OK);
	}
	
	
	@GetMapping("/carts/{name}")
	public ResponseEntity<Cart> findByMenuName(@PathVariable("name") String menu_name) throws CartNotFoundException{
		return new ResponseEntity<Cart>(cartService.findByMenuName(menu_name), HttpStatus.OK);
	}
	
	
	/**
	 * Used to create the resources
	 * @param cart
	 * @return cart
	 */
	@PostMapping("carts")
	public ResponseEntity<Cart> create(@RequestBody Cart cart) {
		String menuName = cart.getMenu().getMenuName();
		Menu menu = menuService.findByMenuName(menuName);
		cart.setMenu(menu);  //associate the menu with the cart

		
		ResponseEntity<Cart> responseEntity;
		responseEntity=new ResponseEntity<>(cartService.create(cart), HttpStatus.CREATED);
		return responseEntity;
	}
	
	
	
	
	@DeleteMapping("/carts/{id}")	
	public void deleteById(@PathVariable("id") int cart_id) {
		 cartService.deleteById(cart_id);
	}

	
	@PutMapping("/carts/{id}")
	public ResponseEntity<Cart> update(@PathVariable("id") int cart_id, @RequestBody Cart cart) {
		return new ResponseEntity<Cart>(cartService.update(cart_id, cart), HttpStatus.ACCEPTED); 
	}
	
}





//@PostMapping("/v1/carts")
//public ResponseEntity<Cart> create(@RequestBody Cart cart) {
//	ResponseEntity<Cart> responseEntity;
//	responseEntity=new ResponseEntity<>(cartService.create(cart), HttpStatus.CREATED);
//	return responseEntity;
//}
