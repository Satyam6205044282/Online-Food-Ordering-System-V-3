package com.satyamcompany.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.satyamcompany.app.exception.CustomerNotFoundException;
import com.satyamcompany.app.model.Customer;
import com.satyamcompany.app.service.CustomerService;


@RestController
@RequestMapping("/api") 
public class CustomerController {
	
	@Autowired
	private CustomerService customerService;
	
	
	/**
	 * 
	 * @return
	 */
	@GetMapping("/customers")
	public ResponseEntity<List<Customer>> findAll(){
		//log
		return new ResponseEntity<>(customerService.findAll(),HttpStatus.OK);
	}
	
	
	/**
	 * 
	 * @param customer_id
	 * @return
	 * @throws CustomerNotFoundException
	 */
	@GetMapping("/customers/{id}")
	public ResponseEntity<Customer> findById(@PathVariable("id") int customer_id) throws CustomerNotFoundException{
		return new ResponseEntity<Customer>(customerService.findById(customer_id), HttpStatus.OK);
	}
	
	
	/**
	 * 
	 * @param customer
	 * @return
	 */
	@PostMapping("/customers")
	public ResponseEntity<Customer> create(@RequestBody Customer customer) {
		ResponseEntity<Customer> responseEntity;
		responseEntity=new ResponseEntity<>(customerService.create(customer), HttpStatus.CREATED);
		return responseEntity;
	}
	
	
	
	/**
	 * 
	 * @param customer_id
	 */
	@DeleteMapping("/customers/{id}")	
	public void deleteById(@PathVariable("id") int customer_id) {
		 customerService.deleteById(customer_id);
	}
	
	/**
	 * 
	 * @param customer_id
	 * @param customer
	 * @return
	 */
	@PutMapping("/customers/{id}")
	public ResponseEntity<Customer> update(@PathVariable("id") int customer_id, @RequestBody Customer customer) {
		return new ResponseEntity<Customer>(customerService.update(customer_id, customer), HttpStatus.ACCEPTED); 
	}
	
	
}
