package com.satyamcompany.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.satyamcompany.app.exception.MenuNotFoundException;
import com.satyamcompany.app.model.Menu;
import com.satyamcompany.app.service.MenuService;

@RestController
@RequestMapping("/api")
public class MenuController {
 
	@Autowired
	private MenuService menuService; 
	
	
	
	/**
	 * 
	 * @return
	 */
	@GetMapping("/menus")
	public ResponseEntity<List<Menu>> findAll(){
		//log
		return new ResponseEntity<>(menuService.findAll(),HttpStatus.OK);
	}
	
	
	/**
	 * 
	 * @param menu_name
	 * @return
	 * @throws MenuNotFoundException
	 */
	@GetMapping("/menus/{name}")
	public ResponseEntity<Menu> findByMenuName(@PathVariable("name") String menu_name) throws MenuNotFoundException{
		return new ResponseEntity<Menu>(menuService.findByMenuName(menu_name), HttpStatus.OK);
	}
	
	
    /**
     * 
     * @param menu
     * @return
     */
	@PostMapping("/menus")
	public ResponseEntity<Menu> create(@RequestBody Menu menu) {
		ResponseEntity<Menu> responseEntity;
		responseEntity=new ResponseEntity<>(menuService.create(menu), HttpStatus.CREATED);
		return responseEntity;
	}
	
	

	
}
