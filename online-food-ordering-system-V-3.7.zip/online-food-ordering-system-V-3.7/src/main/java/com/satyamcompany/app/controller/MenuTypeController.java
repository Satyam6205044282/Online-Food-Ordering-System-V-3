package com.satyamcompany.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.satyamcompany.app.exception.MenuTypeNotFoundException;
import com.satyamcompany.app.model.Menu;
import com.satyamcompany.app.model.MenuType;
import com.satyamcompany.app.service.MenuTypeService;

@RestController
@RequestMapping("/api")
public class MenuTypeController {
 
	@Autowired
	private MenuTypeService menuTypeService;
	
	
	/**
	 * 
	 * @return
	 */
	@GetMapping("/menuTypes")
	public ResponseEntity<List<MenuType>> findAll(){
		//log
		return new ResponseEntity<>(menuTypeService.findAll(),HttpStatus.OK);
	}

	
	
	/**
	 * 
	 * @param type_name
	 * @return
	 * @throws MenuTypeNotFoundException
	 */
	@GetMapping("/menuTypes/{typename}")
	public ResponseEntity<MenuType> findByTypeName(@PathVariable("typename") String type_name) throws MenuTypeNotFoundException{
		return new ResponseEntity<MenuType>(menuTypeService.findByTypeName(type_name), HttpStatus.OK);
	}
	

	/**
	 * 
	 * @param menuType
	 * @return
	 */
	@PostMapping("/menuTypes")
	public ResponseEntity<MenuType> create(@RequestBody MenuType menuType) {
		ResponseEntity<MenuType> responseEntity;
		responseEntity=new ResponseEntity<>(menuTypeService.create(menuType), HttpStatus.CREATED);
		return responseEntity;
	}
	
	

	
}
