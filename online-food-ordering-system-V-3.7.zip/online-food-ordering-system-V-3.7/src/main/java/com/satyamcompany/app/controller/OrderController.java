package com.satyamcompany.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.satyamcompany.app.exception.OrderNotFoundException;
import com.satyamcompany.app.model.Order;
import com.satyamcompany.app.service.OrderService;

@RestController
@RequestMapping("/api")
public class OrderController {

	@Autowired
	private OrderService orderService;
	
	
	
	/**
	 * 
	 * @return
	 */
	@GetMapping("/orders")
	public ResponseEntity<List<Order>> findAll(){
		//log
		return new ResponseEntity<>(orderService.findAll(),HttpStatus.OK);
	}
	
	
	
	/**
	 * 
	 * @param order_id
	 * @return
	 * @throws OrderNotFoundException
	 */
	@GetMapping("/orders/{id}")
	public ResponseEntity<Order> findById(@PathVariable("id") int order_id) throws OrderNotFoundException{
		return new ResponseEntity<Order>(orderService.findById(order_id), HttpStatus.OK);
	}
	
	
	
	
	/**
	 * 
	 * @param order
	 * @return
	 */
	@PostMapping("/orders")
	public ResponseEntity<Order> create(@RequestBody Order order) {
		ResponseEntity<Order> responseEntity;
		responseEntity=new ResponseEntity<>(orderService.create(order), HttpStatus.CREATED);
		return responseEntity;
	}
	
	
}
