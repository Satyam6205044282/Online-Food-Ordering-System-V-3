package com.satyamcompany.app.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.satyamcompany.app.model.Rating;
import com.satyamcompany.app.service.RatingService;

@RestController
@RequestMapping("/api")
public class RatingController {

	@Autowired
	private RatingService ratingService;
	
	
	/**
	 * 
	 * @param rating
	 * @return
	 */
	@PostMapping("/ratings")
	public ResponseEntity<Rating> create(@RequestBody Rating rating) {
		ResponseEntity<Rating> responseEntity;
		responseEntity=new ResponseEntity<>(ratingService.create(rating), HttpStatus.CREATED);
		return responseEntity;
	}
	
	/**
	 * 
	 * @return
	 */
	@GetMapping("/ratings")
	public ResponseEntity<List<Rating>> findAll(){
		//log
		return new ResponseEntity<>(ratingService.findAll(),HttpStatus.OK);
	}
	
}
