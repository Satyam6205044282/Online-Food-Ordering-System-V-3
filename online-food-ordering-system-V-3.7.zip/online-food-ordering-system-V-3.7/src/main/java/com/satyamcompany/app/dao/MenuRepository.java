package com.satyamcompany.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.satyamcompany.app.model.Menu;
import com.satyamcompany.app.model.MenuType;


public interface MenuRepository extends JpaRepository<Menu, Integer>{

	Optional<Menu> findByMenuName(String menu_name);
	  
   
	
}
