package com.satyamcompany.app.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name= "rating")
public class Rating {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int ratingId;
	
	@Column(name= "rate")
    private int rate;
	
	@Column(name= "feedback")
    private String feedback;
	
	@Column(name= "date_recorded")
    private LocalDate dateRecorded= LocalDate.now(); 
	
	@OneToOne
	@JoinColumn(name = "order_id")
	private Order order;
	
	
	
	
	
	
	public Rating(int rate, String feedback, LocalDate dateRecorded, Menu menu, Customer customer) {
		super();
	
		this.rate = rate;
		this.feedback = feedback;
		this.dateRecorded = dateRecorded;
		
	
	}
	
	
	
	public Rating(int rate, String feedback, LocalDate dateRecorded, Order order2, Customer customer) {
		super();
	}
		
}
