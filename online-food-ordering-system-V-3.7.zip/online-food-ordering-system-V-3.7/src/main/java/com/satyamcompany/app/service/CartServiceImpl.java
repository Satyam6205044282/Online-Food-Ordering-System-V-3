package com.satyamcompany.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service; 

import com.satyamcompany.app.dao.CartRepository;
import com.satyamcompany.app.dao.MenuRepository;
import com.satyamcompany.app.exception.CartNotFoundException;
import com.satyamcompany.app.model.Cart;
import com.satyamcompany.app.model.Menu;


@Service
public class CartServiceImpl implements CartService{
	
	@Autowired
	private CartRepository repository;
	
	@Autowired
	private MenuRepository menuRepository; 
	
	@Override
	public Cart create(Cart cart){
		Optional<Menu> optionalMenu = menuRepository.findById(cart.getMenu().getMenuId());
		Menu menu = optionalMenu.get();
		cart.setMenu(menu);
		cart.setMenuName(menu.getMenuName()); 
		cart.setPrice(menu.getPrice());
		cart.setTotalAmount(menu.getPrice()*cart.getQuantity());
		return repository.save(cart);
	}
	
	@Override
	public List<Cart> findAll() {
	
		return repository.findAll();
	}
	
	@Override
	public Cart findById(int customer_id) throws CartNotFoundException{
		Optional<Cart>optional= repository.findById(customer_id);
		if(optional.isEmpty()) {
		throw new CartNotFoundException("Cart Not Found By Cart Id: " + customer_id);
		}
		return optional.get();
	}
	

	@Override
	public Cart findByMenuName(String menu_name) throws CartNotFoundException{
		Optional<Cart>optional= repository.findByMenuName(menu_name);
		if(optional.isEmpty()) {
		throw new CartNotFoundException("Cart Not Found By Menu Name: " + menu_name);
		}
		return optional.get();
	}
  
	@Override
	public void deleteById(int cart_id)throws CartNotFoundException {
		Cart cart= findById(cart_id);    
		repository.deleteById(cart_id); 
	}
	
	@Override
	public Cart update(int cart_id, Cart newCart) throws CartNotFoundException{
		Cart  cart=findById(cart_id);
		return repository.save(newCart);
	}
}
