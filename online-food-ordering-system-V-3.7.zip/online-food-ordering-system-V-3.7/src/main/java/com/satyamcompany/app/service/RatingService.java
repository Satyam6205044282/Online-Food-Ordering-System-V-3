package com.satyamcompany.app.service;

import java.util.List;

import com.satyamcompany.app.model.Rating;

public interface RatingService {
	public Rating create(Rating rating);

	public List<Rating> findAll(); 
}
