package com.satyamcompany.app.controller;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.satyamcompany.app.exception.CartNotFoundException;
import com.satyamcompany.app.model.Cart;
import com.satyamcompany.app.model.Menu;
import com.satyamcompany.app.service.CartService;
import com.satyamcompany.app.service.MenuService;

class CartControllerTest {
	
	@InjectMocks
	CartController cartController;
	
	@Mock
	CartService cartService;
	
	@Mock
	MenuService menuService;
	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testFindAll() {
		List<Cart> carts = new ArrayList<>();
		carts.add(new Cart(1, "Pizza", 10.0f, 2, 20.0f, 1, new Menu("Pizza", 10.0f)));
		carts.add(new Cart(2, "Burger", 5.0f, 3, 15.0f, 2, new Menu("Burger", 5.0f)));
		when(cartService.findAll()).thenReturn(carts);
		
		ResponseEntity<List<Cart>> response = cartController.findAll();
		
		assert(response.getStatusCode().equals(HttpStatus.OK));
		assert(response.getBody().size() == 2);
	}

	@Test
	void testFindById() throws CartNotFoundException {
		Cart cart = new Cart(1, "Pizza", 10.0f, 2, 20.0f, 1, new Menu("Pizza", 10.0f));
		when(cartService.findById(1)).thenReturn(cart);
		
		ResponseEntity<Cart> response = cartController.findById(1);
		
		assert(response.getStatusCode().equals(HttpStatus.OK));
		assert(response.getBody().equals(cart));
	}

	@Test
	void testFindByMenuName() throws CartNotFoundException {
		Cart cart = new Cart(1, "Pizza", 10.0f, 2, 20.0f, 1, new Menu("Pizza", 10.0f));
		when(cartService.findByMenuName("Pizza")).thenReturn(cart);
		
		ResponseEntity<Cart> response = cartController.findByMenuName("Pizza");
		
		assert(response.getStatusCode().equals(HttpStatus.OK));
		assert(response.getBody().equals(cart));
	}

	@Test
	void testCreate() {
		Cart cart = new Cart(1, "Pizza", 10.0f, 2, 20.0f, 1, new Menu("Pizza", 10.0f));
		when(menuService.findByMenuName("Pizza")).thenReturn(new Menu("Pizza", 10.0f));
		when(cartService.create(cart)).thenReturn(cart);
		
		ResponseEntity<Cart> response = cartController.create(cart);
		
		assert(response.getStatusCode().equals(HttpStatus.CREATED));
		assert(response.getBody().equals(cart));
	}

	@Test
	void testDeleteById() {
		cartController.deleteById(1);
	}

	@Test
	void testUpdate() {
		Cart cart = new Cart(1, "Pizza", 10.0f, 2, 20.0f, 1, new Menu("Pizza", 10.0f));
		when(cartService.update(1, cart)).thenReturn(cart);
		
		ResponseEntity<Cart> response = cartController.update(1, cart);
		assert(response.getStatusCode().equals(HttpStatus.ACCEPTED));  
		assert(response.getBody().equals(cart));
	}
}
		



















//package com.satyamcompany.app.controller;
//
//import static org.assertj.core.api.Assertions.assertThat;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//
//import java.util.Arrays;
//import java.util.List;
//import java.util.Optional;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.mockito.MockitoAnnotations;
//
//import com.satyamcompany.app.dao.CartRepository;
//import com.satyamcompany.app.exception.CartNotFoundException;
//import com.satyamcompany.app.model.Cart;
//import com.satyamcompany.app.model.Menu;
//import com.satyamcompany.app.service.CartServiceImpl;
//
//public class CartControllerTest {
//
//    @Mock
//    private CartRepository cartRepositoryMock;
//
//    @InjectMocks
//    private CartServiceImpl cartService;
//
//    private Cart cart1;
//    private Cart cart2;
//
//	private Menu menu1;
//	private Menu menu2;
//
//    @BeforeEach
//    public void setUp() {
//        MockitoAnnotations.openMocks(this);
//
////        Menu menu1 = new Menu(1, "Veg-items", "All the starter and main courses are available.");
////        Menu menu2 = new Menu(1, "Non-Veg items", "All the non veg items of the main courses are available.");
//
//        cart1 = new Cart(1, "menu1", 100.0f, 2, 200.0f, 1, menu1);  
//        cart2 = new Cart(2, "menu2", 200.0f, 1, 200.0f, 2, menu2);
//    }
//
//    @Test
//    public void testCreate() {
//        Mockito.when(cartRepositoryMock.save(cart1)).thenReturn(cart1);
//
//        Cart createdCart = cartService.create(cart1);
//
//        assertThat(createdCart).isEqualTo(cart1);
//        Mockito.verify(cartRepositoryMock, Mockito.times(1)).save(cart1);
//    }
//
//    @Test
//    public void testFindAll() {
//        Mockito.when(cartRepositoryMock.findAll()).thenReturn(Arrays.asList(cart1, cart2));
//
//        List<Cart> cartList = cartService.findAll();
//
//        assertThat(cartList).hasSize(2).contains(cart1, cart2);
//        Mockito.verify(cartRepositoryMock, Mockito.times(1)).findAll();
//    }
//
//    @Test
//    public void testFindById() throws CartNotFoundException {
//        Mockito.when(cartRepositoryMock.findById(cart1.getCartId())).thenReturn(Optional.of(cart1));
//
//        Cart foundCart = cartService.findById(cart1.getCartId());
//
//        assertThat(foundCart).isEqualTo(cart1);
//        Mockito.verify(cartRepositoryMock, Mockito.times(1)).findById(cart1.getCartId());
//
//        assertThrows(CartNotFoundException.class, () -> {
//            cartService.findById(-1);
//        });
//    }
//
//    @Test
//    public void testDeleteById() throws CartNotFoundException {
//        Mockito.when(cartRepositoryMock.findById(cart1.getCartId())).thenReturn(Optional.of(cart1));
//
//        cartService.deleteById(cart1.getCartId());
//
//        Mockito.verify(cartRepositoryMock, Mockito.times(1)).deleteById(cart1.getCartId());
//
//        assertThrows(CartNotFoundException.class, () -> {
//            cartService.deleteById(-1);
//        });
//    }
//
//    @Test
//    public void testUpdate() throws CartNotFoundException {
//        Mockito.when(cartRepositoryMock.findById(cart1.getCartId())).thenReturn(Optional.of(cart1));
//
//        Cart updatedCart = new Cart("menu1", 100.0f, 3, 300.0f, 1, cart1.getMenu());
//        Mockito.when(cartRepositoryMock.save(updatedCart)).thenReturn(updatedCart);
//
//        Cart returnedCart = cartService.update(cart1.getCartId(), updatedCart);
//
//        assertEquals(updatedCart.getQuantity(), returnedCart.getQuantity());
//        Mockito.verify(cartRepositoryMock, Mockito.times(1)).findById(cart1.getCartId());
//        Mockito.verify(cartRepositoryMock, Mockito.times(1)).findById(cart1.getCartId());
//        
//        assertThrows(CartNotFoundException.class, () -> {
//            cartService.update(1, returnedCart); 
//        });
//    }