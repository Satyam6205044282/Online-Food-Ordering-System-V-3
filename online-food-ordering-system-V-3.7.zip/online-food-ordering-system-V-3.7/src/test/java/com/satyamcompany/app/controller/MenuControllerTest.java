package com.satyamcompany.app.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.satyamcompany.app.exception.MenuNotFoundException;
import com.satyamcompany.app.model.Menu;
import com.satyamcompany.app.service.MenuService;

public class MenuControllerTest {

    @Mock
    private MenuService menuService;

    @InjectMocks
    private MenuController menuController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testFindAll() {
        // Create mock data
        List<Menu> menus = new ArrayList<>();
        Menu menu1 = new Menu("Burger", 5.0f);
        Menu menu2 = new Menu("Pizza", 10.0f);
        menus.add(menu1);
        menus.add(menu2);

        // Mock the service method
        when(menuService.findAll()).thenReturn(menus);

        // Call the controller method
        ResponseEntity<List<Menu>> response = menuController.findAll();

        // Assertions
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(2, response.getBody().size());
    }

    @Test
    public void testFindByMenuName() throws MenuNotFoundException {
        // Create mock data
        Menu menu = new Menu("Burger", 5.0f);

        // Mock the service method
        when(menuService.findByMenuName("Burger")).thenReturn(menu);

        // Call the controller method
        ResponseEntity<Menu> response = menuController.findByMenuName("Burger");

        // Assertions
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Burger", response.getBody().getMenuName());
    }

   

    @Test
    public void testCreate() {
        // Create mock data
        Menu menu = new Menu("Burger", 5.0f);

        // Mock the service method
        when(menuService.create(menu)).thenReturn(menu);

        // Call the controller method
        ResponseEntity<Menu> response = menuController.create(menu);

        // Assertions
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Burger", response.getBody().getMenuName());
    }
}





















//package com.satyamcompany.app.controller;
//
//import static org.hamcrest.MatcherAssert.assertThat;
//import static org.hamcrest.Matchers.*;
//import static org.mockito.Mockito.when;
//
//import java.util.Arrays;
//import java.util.List;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.mockito.junit.jupiter.MockitoExtension;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//
//import com.satyamcompany.app.exception.MenuNotFoundException;
//import com.satyamcompany.app.model.Menu;
//import com.satyamcompany.app.service.MenuService;
//
//@ExtendWith(MockitoExtension.class)
//class MenuControllerTest {
//
//	@InjectMocks
//	private MenuController menuController;
//
//	@Mock
//	private MenuService menuService;
//
//	private List<Menu> menuList;
//
//	@BeforeEach
//	void setUp() throws Exception {
//		MockitoAnnotations.initMocks(this);
//
//		Menu menu1 = new Menu(1, "Menu1", 10.0f, null);
//		Menu menu2 = new Menu(2, "Menu2", 20.0f, null);
//
//		menuList = Arrays.asList(menu1, menu2);
//	}
//
//	
//	@Test
//	void testFindAll() {
//		when(menuService.findAll()).thenReturn(menuList);
//
//		ResponseEntity<List<Menu>> response = menuController.findAll();
//
//		assertThat(response.getStatusCode(), is(HttpStatus.OK));
//		assertThat(response.getBody(), is(menuList));
//	}
//
//	
//
//	@Test
//	void testFindByMenuName() throws MenuNotFoundException {
//		String menuName = "Menu1";
//		Menu menu = new Menu(1, menuName, 10.0f, null);
//
//		when(menuService.findByMenuName(menuName)).thenReturn(menu);
//
//		ResponseEntity<Menu> response = menuController.findByMenuName(menuName);
//
//		assertThat(response.getStatusCode(), is(HttpStatus.OK));
//		assertThat(response.getBody(), is(menu));
//	}
//
//	
//
//	@Test
//	void testCreate() {
//		String menuName = "Menu3";
//		float price = 30.0f;
//		Menu menu = new Menu(menuName, price);
//
//		when(menuService.create(menu)).thenReturn(menu);
//
//		ResponseEntity<Menu> result = menuController.create(menu);
//
//		assertThat(result.getStatusCode(), is(HttpStatus.CREATED));
//		assertThat(result.getBody(), is(menu));
//	}
//
//}