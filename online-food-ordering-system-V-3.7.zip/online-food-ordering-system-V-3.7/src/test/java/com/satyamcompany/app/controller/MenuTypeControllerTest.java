package com.satyamcompany.app.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.satyamcompany.app.exception.MenuTypeNotFoundException;
import com.satyamcompany.app.model.MenuType;
import com.satyamcompany.app.service.MenuTypeService;

@ExtendWith(MockitoExtension.class)
public class MenuTypeControllerTest {

    @Mock
    private MenuTypeService menuTypeService;

    @InjectMocks
    private MenuTypeController menuTypeController;

    @Test
    public void testFindAll() {
        List<MenuType> list = new ArrayList<>();
        MenuType menuType = new MenuType("type1", "description1");
        list.add(menuType);
        when(menuTypeService.findAll()).thenReturn(list);
        ResponseEntity<List<MenuType>> responseEntity = menuTypeController.findAll();
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertNotNull(responseEntity.getBody());
        assertEquals(list, responseEntity.getBody());
        verify(menuTypeService, times(1)).findAll();
    }

    @Test
    public void testFindByTypeName() throws MenuTypeNotFoundException {
        String typeName = "type1";
        MenuType menuType = new MenuType("type1", "description1");
        when(menuTypeService.findByTypeName(typeName)).thenReturn(menuType);
        ResponseEntity<MenuType> responseEntity = menuTypeController.findByTypeName(typeName);
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertNotNull(responseEntity.getBody());
        assertEquals(menuType, responseEntity.getBody());
        verify(menuTypeService, times(1)).findByTypeName(typeName);
    }


    @Test
    public void testCreate() {
        MenuType menuType = new MenuType("type1", "description1");
        when(menuTypeService.create(menuType)).thenReturn(menuType);
        ResponseEntity<MenuType> responseEntity = menuTypeController.create(menuType);
        assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
        assertNotNull(responseEntity.getBody());
        assertEquals(menuType, responseEntity.getBody());
        verify(menuTypeService, times(1)).create(menuType);
    }

}
