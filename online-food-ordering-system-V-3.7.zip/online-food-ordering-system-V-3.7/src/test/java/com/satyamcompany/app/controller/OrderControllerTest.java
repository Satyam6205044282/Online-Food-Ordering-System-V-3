package com.satyamcompany.app.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.satyamcompany.app.exception.OrderNotFoundException;
import com.satyamcompany.app.model.Cart;
import com.satyamcompany.app.model.Customer;
import com.satyamcompany.app.model.Order;
import com.satyamcompany.app.service.OrderService;

public class OrderControllerTest {

	@InjectMocks
	OrderController orderController;
	
	@Mock
	OrderService orderService;
	
	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	public void testFindAll() {
		List<Order> orders = new ArrayList<Order>();
		Customer customer = new Customer();
		Cart cart = new Cart();
		Order order = new Order(1, LocalDate.now(), 100.0f, customer, cart);
		orders.add(order);
		
		when(orderService.findAll()).thenReturn(orders);
		
		ResponseEntity<List<Order>> response = orderController.findAll();
		
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(1, response.getBody().size());
	}
	
	@Test
	public void testFindById() throws OrderNotFoundException {
		Customer customer = new Customer();
		Cart cart = new Cart();
		Order order = new Order(1, LocalDate.now(), 100.0f, customer, cart);
		
		when(orderService.findById(anyInt())).thenReturn(order);
		
		ResponseEntity<Order> response = orderController.findById(1);
		
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
	}
	
	@Test
	public void testCreate() {
		Customer customer = new Customer();
		Cart cart = new Cart();
		Order order = new Order(1, LocalDate.now(), 100.0f, customer, cart);
		
		when(orderService.create(order)).thenReturn(order);
		
		ResponseEntity<Order> response = orderController.create(order);
		
		assertEquals(HttpStatus.CREATED, response.getStatusCode());
		assertNotNull(response.getBody());
	}
}