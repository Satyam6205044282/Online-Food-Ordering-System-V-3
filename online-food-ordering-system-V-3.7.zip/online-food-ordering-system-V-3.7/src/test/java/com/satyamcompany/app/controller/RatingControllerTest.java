package com.satyamcompany.app.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.satyamcompany.app.model.Order;
import com.satyamcompany.app.model.Rating;
import com.satyamcompany.app.service.RatingService;

public class RatingControllerTest {

	@InjectMocks
	private RatingController ratingController;

	@Mock
	private RatingService ratingService;

	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void testCreate() {
		Order order1= new Order();
		Rating rating = new Rating(1, "nice", LocalDate.now(), order1, null);
		when(ratingService.create(rating)).thenReturn(rating);
		ResponseEntity<Rating> responseEntity = ratingController.create(rating);
		assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.CREATED);
		assertThat(responseEntity.getBody()).isEqualTo(rating);
	}

	@Test
	public void testFindAll() {
		List<Rating> ratings = new ArrayList<>();
		Rating rating1 = new Rating();
		Rating rating2 = new Rating();
		ratings.add(rating1);
		ratings.add(rating2);
		when(ratingService.findAll()).thenReturn(ratings);
		ResponseEntity<List<Rating>> responseEntity = ratingController.findAll();
		assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(responseEntity.getBody()).isEqualTo(ratings);
	}
}