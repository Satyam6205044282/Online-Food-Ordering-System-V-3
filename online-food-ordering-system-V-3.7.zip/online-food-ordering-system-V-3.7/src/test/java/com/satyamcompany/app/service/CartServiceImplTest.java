package com.satyamcompany.app.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.satyamcompany.app.dao.CartRepository;
import com.satyamcompany.app.dao.MenuRepository;
import com.satyamcompany.app.exception.CartNotFoundException;
import com.satyamcompany.app.model.Cart;
import com.satyamcompany.app.model.Menu;

@ExtendWith(MockitoExtension.class)
public class CartServiceImplTest {

    @Mock
    private CartRepository cartRepository;

    @Mock
    private MenuRepository menuRepository;

    @InjectMocks
    private CartServiceImpl cartService;

    private Cart cart;
    private Menu menu;

    @BeforeEach
    void setUp() {
        menu = new Menu(1, "Burger", 100.0f, null);
        cart = new Cart(1, "Pizza", 10.0f, 2, 20.0f, 1, new Menu("Pizza", 10.0f));
    }

    

    @Test
    void testFindAll() {
        // mock repository behavior
        List<Cart> expected = Arrays.asList(cart);
        when(cartRepository.findAll()).thenReturn(expected);

        // invoke the service method
        List<Cart> result = cartService.findAll();

        // assert the result
        assertNotNull(result);
        assertEquals(expected, result);
    }

    @Test
    void testFindById() {
        // mock repository behavior
        when(cartRepository.findById(1)).thenReturn(Optional.of(cart));

        // invoke the service method
        Cart result = cartService.findById(1);

        // assert the result
        assertNotNull(result);
        assertEquals(cart, result);

        // test exception scenario
        assertThrows(CartNotFoundException.class, () -> {
            cartService.findById(2);
        });
    }

    @Test
    void testFindByMenuName() {
        // mock repository behavior
        when(cartRepository.findByMenuName("Burger")).thenReturn(Optional.of(cart));

        // invoke the service method
        Cart result = cartService.findByMenuName("Burger");

        // assert the result
        assertNotNull(result);
        assertEquals(cart, result);

        // test exception scenario
        assertThrows(CartNotFoundException.class, () -> {
            cartService.findByMenuName("Pizza");
        });
    }
    
    
    @Disabled
    @Test
    void testCreate() {
        // mock menuRepository behavior
        when(menuRepository.findById(1)).thenReturn(Optional.of(menu));

        // mock repository behavior
        when(cartRepository.save(cart)).thenReturn(cart);

        // invoke the service method
        Cart result = cartService.create(cart);

        // assert the result
        assertNotNull(result);
        assertEquals("Burger", result.getMenuName());
        assertEquals(100.0f, result.getPrice(), 0.1f);
        assertEquals(2, result.getQuantity());
        assertEquals(200.0f, result.getTotalAmount(), 0.1f);
    }
    
    
    
  @Test
  public void testDeleteCartById() throws CartNotFoundException {
      Mockito.when(cartRepository.findById(1)).thenReturn(Optional.of(cart));

      cartService.deleteById(1);

      Mockito.verify(cartRepository, Mockito.times(1)).deleteById(1);

      assertThrows(CartNotFoundException.class, () -> {
          cartService.deleteById(99);
      });
  }

  @Test
  public void testUpdateCart() throws CartNotFoundException {
      Cart newCart = new Cart(1, "Pizza", 10.0f, 2, 20.0f, 1, new Menu("Pizza", 10.0f));
      newCart.setCartId(1);

      Mockito.when(cartRepository.findById(1)).thenReturn(Optional.of(cart));
      Mockito.when(cartRepository.save(Mockito.any(Cart.class))).thenReturn(newCart);

      Cart updatedCart = cartService.update(1, newCart);

      assertEquals(newCart, updatedCart);
      Mockito.verify(cartRepository, Mockito.times(1)).findById(1);
      Mockito.verify(cartRepository, Mockito.times(1)).save(newCart);

      assertThrows(CartNotFoundException.class, () -> {
          cartService.update(99, newCart);
      });
  }
  
}


























//package com.satyamcompany.app.service;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//import java.util.Arrays;
//import java.util.List;
//import java.util.Optional;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Disabled;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.mockito.MockitoAnnotations;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.data.repository.CrudRepository;
//
//import com.satyamcompany.app.service.CartService;
//import com.satyamcompany.app.service.MenuService;
//import com.satyamcompany.app.dao.CartRepository;
//import com.satyamcompany.app.dao.MenuRepository;
//import com.satyamcompany.app.exception.CartNotFoundException;
//import com.satyamcompany.app.model.Cart;
//import com.satyamcompany.app.model.Menu;
//
//@SpringBootTest
//public class CartServiceImplTest {
//
//    @Mock
//    private CartRepository cartRepository;
//    private MenuRepository menuRepository;
//
//    @InjectMocks
//    private CartServiceImpl cartService;
//    private MenuServiceImpl menuService;
//
//    private Cart cart1;
//    private Cart cart2;
//
//    @BeforeEach
//    public void setup() {
//        MockitoAnnotations.openMocks(this);
//
//        cart1 = new Cart(1, "Pizza", 10.0f, 2, 20.0f, 1, new Menu("Pizza", 10.0f));
//        cart1.setCartId(1);
//
//        cart2 = new Cart(2, "Burger", 10.0f, 2, 20.0f, 1, new Menu("Burger", 10.0f));
//        cart2.setCartId(2);
//    }
//
//    
////    @Test
////	public void testCreate() {
////		Menu menu = new Menu();
////		menu.setMenuId(1);
////		menu.setMenuName("Vegetable Pakora");
////		menu.setPrice(10.0f);
////		Cart cart = new Cart();
////		cart.setMenu(menu);
////		cart.setQuantity(2);
////		cart.setCustomerId(1);
////
////		Mockito.when(menuRepository.findByMenuName("Vegetable Pakora")).thenReturn(Optional.of(menu)); 
////		Mockito.when(cartRepository.save(cart)).thenReturn(cart);
////
////		Cart createdCart = cartService.create(cart);
////
////		assertEquals(cart, createdCart);
////		assertEquals(cart.getTotalAmount(), 20.0f);
////		assertEquals(cart.getPrice(), 10.0f);
////		assertEquals(cart.getMenuName(), "Vegetable Pakora");
////	}
//    
//    
//    
//    
//    @Test
//	public void testCreate() {
//		// Create a new menu item first
//		Menu menu = new Menu(1, "Pizza", 12.50f, null);
//		
//		menu = menuService.create(menu);
//		
//		// Create a new cart item
//		Cart cart = new Cart("Pizza", menu.getPrice(), 2, menu.getPrice() * 2, 1, menu);
//	
//		cart = cartService.create(cart);
//		
//		assertNotNull(cart.getCartId());
//		assertEquals(cart.getMenuName(), "Pizza");
//		assertEquals(cart.getPrice(), 12.50f, 0.01);
//		assertEquals(cart.getQuantity(), 2);
//		assertEquals(cart.getTotalAmount(), 25.00f, 0.01);
//	}
//   
//
//    @Test
//    public void testFindAllCarts() {
//        Mockito.when(cartRepository.findAll()).thenReturn(Arrays.asList(cart1, cart2));
//
//        List<Cart> carts = cartService.findAll();
//
//        assertEquals(2, carts.size());
//        assertTrue(carts.contains(cart1));
//        assertTrue(carts.contains(cart2));
//        Mockito.verify(cartRepository, Mockito.times(1)).findAll();
//    }
//
//    @Test
//    public void testFindCartById() throws CartNotFoundException {
//        Mockito.when(cartRepository.findById(1)).thenReturn(Optional.of(cart1));
//
//        Cart foundCart = cartService.findById(1);
//
//        assertEquals(cart1, foundCart);
//        Mockito.verify(cartRepository, Mockito.times(1)).findById(1);
//
//        assertThrows(CartNotFoundException.class, () -> {
//            cartService.findById(99);
//        });
//    }
//
//    @Test
//    public void testDeleteCartById() throws CartNotFoundException {
//        Mockito.when(cartRepository.findById(1)).thenReturn(Optional.of(cart1));
//
//        cartService.deleteById(1);
//
//        Mockito.verify(cartRepository, Mockito.times(1)).deleteById(1);
//
//        assertThrows(CartNotFoundException.class, () -> {
//            cartService.deleteById(99);
//        });
//    }
//
//    @Test
//    public void testUpdateCart() throws CartNotFoundException {
//        Cart newCart = new Cart(1, "Pizza", 10.0f, 2, 20.0f, 1, new Menu("Pizza", 10.0f));
//        newCart.setCartId(1);
//
//        Mockito.when(cartRepository.findById(1)).thenReturn(Optional.of(cart1));
//        Mockito.when(cartRepository.save(Mockito.any(Cart.class))).thenReturn(newCart);
//
//        Cart updatedCart = cartService.update(1, newCart);
//
//        assertEquals(newCart, updatedCart);
//        Mockito.verify(cartRepository, Mockito.times(1)).findById(1);
//        Mockito.verify(cartRepository, Mockito.times(1)).save(newCart);
//
//        assertThrows(CartNotFoundException.class, () -> {
//            cartService.update(99, newCart);
//        });
//    }
//}