package com.satyamcompany.app.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.satyamcompany.app.dao.CartRepository;
import com.satyamcompany.app.dao.OrderRepository;
import com.satyamcompany.app.exception.OrderNotFoundException;
import com.satyamcompany.app.model.Cart;
import com.satyamcompany.app.model.Customer;
import com.satyamcompany.app.model.Order;

public class OrderServiceImplTest {
    
    @Mock
    private OrderRepository orderRepository;
    
    @Mock
    private CartRepository cartRepository;
    
    @InjectMocks
    private OrderServiceImpl orderService;
    
    private Order order;
    private Cart cart;
    private Customer customer;
    
    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        customer = new Customer("John", "Doe", "john.doe@gmail.com", "1234567890", "johndoe", "John123");
        cart = new Cart();
        order = new Order(LocalDate.now(), 100.0f, customer, cart);
        order.setOrderId(1);
        when(cartRepository.findById(cart.getCartId())).thenReturn(Optional.of(cart));
        when(orderRepository.findById(order.getOrderId())).thenReturn(Optional.of(order));
        when(orderRepository.findAll()).thenReturn(Arrays.asList(order));
    }
    
    @Test
    public void testCreateOrder() {
        when(orderRepository.save(order)).thenReturn(order);
        Order createdOrder = orderService.create(order);
        assertNotNull(createdOrder);
        assertEquals(order.getOrderId(), createdOrder.getOrderId());
        assertEquals(order.getOrderDate(), createdOrder.getOrderDate());
        assertEquals(order.getTotalAmount(), createdOrder.getTotalAmount(), 100.0f);
        assertEquals(order.getCustomer(), createdOrder.getCustomer());
        assertEquals(order.getCart(), createdOrder.getCart());
    }
    
    @Test
    public void testFindAllOrders() {
        List<Order> orders = orderService.findAll();
        assertNotNull(orders);
        assertTrue(orders.size() > 0);
        assertEquals(order.getOrderId(), orders.get(0).getOrderId());
        assertEquals(order.getOrderDate(), orders.get(0).getOrderDate());
        assertEquals(order.getTotalAmount(), orders.get(0).getTotalAmount(), 100.0f);
        assertEquals(order.getCustomer(), orders.get(0).getCustomer());
        assertEquals(order.getCart(), orders.get(0).getCart());
    }
    
    @Test
    public void testFindOrderById() throws OrderNotFoundException {
        Order foundOrder = orderService.findById(order.getOrderId());
        assertNotNull(foundOrder);
        assertEquals(order.getOrderId(), foundOrder.getOrderId());
        assertEquals(order.getOrderDate(), foundOrder.getOrderDate());
        assertEquals(order.getTotalAmount(), foundOrder.getTotalAmount(), 100.0f);
        assertEquals(order.getCustomer(), foundOrder.getCustomer());
        assertEquals(order.getCart(), foundOrder.getCart());
    }
    
}