package com.satyamcompany.app.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.satyamcompany.app.dao.RatingRepository;
import com.satyamcompany.app.model.Order;
import com.satyamcompany.app.model.Rating;

public class RatingServiceImplTest {

    @Mock
    private RatingRepository ratingRepository;

    @InjectMocks
    private RatingServiceImpl ratingService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateRating() {
        Order order = mock(Order.class);
        Rating rating = new Rating(5, "Great food", LocalDate.now(), order, null);
        rating.setOrder(order);
        when(ratingRepository.save(rating)).thenReturn(rating);

        Rating result = ratingService.create(rating);

        assertEquals(rating, result);
    }

    @Test
    public void testFindAllRatings() {
    	 Order order1 = mock(Order.class);
    	 Order order2 = mock(Order.class);
        Rating rating1 = new Rating(5, "Great food", LocalDate.now(), order1, null);
        Rating rating2 = new Rating(3, "Okay food", LocalDate.now(), order2, null);
        List<Rating> ratings = Arrays.asList(rating1, rating2);

        when(ratingRepository.findAll()).thenReturn(ratings);

        List<Rating> result = ratingService.findAll();

        assertEquals(ratings, result);
    }
}